export type Time = {
    hour: number,
    minutes:  number
}