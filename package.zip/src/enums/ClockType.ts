export enum ClockType {
    SECOND,
    MINUTE,
    HOUR,
    DAY
}